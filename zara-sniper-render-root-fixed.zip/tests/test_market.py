from zara_sniper.market import pair_metrics, best_pair

def test_pair_metrics():
    p = {'liquidity': {'usd': 1234}, 'volume': {'h24': 456}, 'pairCreatedAt': None}
    assert pair_metrics(p) == (1234.0, 456.0, None)

def test_best_pair_prefers_liquidity():
    pairs = [{'liquidity': {'usd': 10}}, {'liquidity': {'usd': 100}}]
    assert best_pair(pairs) == pairs[1]


def test_pair_metrics_unknown_age_and_missing_fields():
    assert pair_metrics({}) == (0.0, 0.0, None)


def test_best_pair_empty_list():
    assert best_pair([]) is None
