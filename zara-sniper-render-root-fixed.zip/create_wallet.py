"""Create a fresh Solana keypair locally. Run only in a private terminal."""
import base58
from solders.keypair import Keypair

kp = Keypair()
secret = base58.b58encode(bytes(kp)).decode("ascii")
print("NEW SOLANA TRADING WALLET CREATED")
print("Public address:", kp.pubkey())
print("Private key (keep secret; set as SOLANA_PRIVATE_KEY in Render):")
print(secret)
print("\nWrite the private key down securely. Never paste it into Telegram, GitHub, or a chat.")
print("Fund only after checking the public address and verifying the bot deployment settings.")
