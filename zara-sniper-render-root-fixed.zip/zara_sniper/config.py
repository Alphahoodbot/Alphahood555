from dataclasses import dataclass
import os
from dotenv import load_dotenv

load_dotenv()

def _float(name: str, default: str) -> float:
    try:
        return float(os.getenv(name, default))
    except ValueError:
        raise RuntimeError(f"{name} must be a number")

def _int(name: str, default: str) -> int:
    try:
        return int(os.getenv(name, default))
    except ValueError:
        raise RuntimeError(f"{name} must be an integer")

@dataclass(frozen=True)
class Config:
    telegram_token: str = os.getenv("TELEGRAM_BOT_TOKEN", "")
    owner_id: int = _int("OWNER_ID", "0")
    trading_mode: str = os.getenv("TRADING_MODE", "live").lower()
    solana_rpc_url: str = os.getenv("SOLANA_RPC_URL", "")
    solana_private_key: str = os.getenv("SOLANA_PRIVATE_KEY", "")
    jupiter_api_key: str = os.getenv("JUPITER_API_KEY", "")
    database_path: str = os.getenv("DATABASE_PATH", "data/zara_sniper.sqlite3")
    min_liquidity_usd: float = _float("MIN_LIQUIDITY_USD", "15000")
    min_volume_24h_usd: float = _float("MIN_VOLUME_24H_USD", "5000")
    max_token_age_hours: float = _float("MAX_TOKEN_AGE_HOURS", "24")
    max_position_sol: float = _float("MAX_POSITION_SOL", "0.05")
    max_daily_spend_sol: float = _float("MAX_DAILY_SPEND_SOL", "0.25")
    max_slippage_bps: int = _int("MAX_SLIPPAGE_BPS", "500")
    priority_fee_lamports: int = _int("PRIORITY_FEE_LAMPORTS", "100000")
    scan_interval_seconds: int = _int("SCAN_INTERVAL_SECONDS", "20")
    auto_buy_enabled_at_start: bool = os.getenv("AUTO_BUY_ENABLED_AT_START", "false").lower() == "true"

    def __post_init__(self):
        if self.trading_mode not in ("live", "paper"):
            raise RuntimeError("TRADING_MODE must be 'live' or 'paper'")
        if self.owner_id < 0:
            raise RuntimeError("OWNER_ID must be a positive Telegram user ID")
        if self.max_position_sol <= 0 or self.max_daily_spend_sol <= 0:
            raise RuntimeError("MAX_POSITION_SOL and MAX_DAILY_SPEND_SOL must be positive")
        if self.max_slippage_bps < 1 or self.max_slippage_bps > 5000:
            raise RuntimeError("MAX_SLIPPAGE_BPS must be between 1 and 5000")
        if self.scan_interval_seconds < 5:
            raise RuntimeError("SCAN_INTERVAL_SECONDS must be at least 5 seconds")

config = Config()
