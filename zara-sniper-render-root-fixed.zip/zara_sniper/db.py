import os
import aiosqlite
from .config import config

async def connect():
    parent = os.path.dirname(config.database_path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    db = await aiosqlite.connect(config.database_path)
    db.row_factory = aiosqlite.Row
    return db

async def init_db():
    async with await connect() as db:
        await db.executescript('''
        CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS trades (
          id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT DEFAULT CURRENT_TIMESTAMP,
          side TEXT NOT NULL, mint TEXT NOT NULL, symbol TEXT, amount_sol REAL NOT NULL DEFAULT 0,
          price_usd REAL, status TEXT NOT NULL, note TEXT, signature TEXT, engine TEXT
        );
        CREATE TABLE IF NOT EXISTS positions (
          mint TEXT PRIMARY KEY, symbol TEXT, amount_sol REAL NOT NULL,
          entry_price_usd REAL NOT NULL, quantity REAL NOT NULL DEFAULT 0,
          quantity_raw TEXT DEFAULT '0', decimals INTEGER DEFAULT 0,
          engine TEXT DEFAULT 'jupiter', buy_signature TEXT,
          opened_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS seen_tokens (mint TEXT PRIMARY KEY, first_seen TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS daily_spend (day TEXT PRIMARY KEY, amount_sol REAL NOT NULL DEFAULT 0);
        ''')
        # Safe additive migrations for an older database.
        for table, col, definition in [
            ('trades','signature','TEXT'), ('trades','engine','TEXT'),
            ('positions','quantity_raw',"TEXT DEFAULT '0'"), ('positions','decimals','INTEGER DEFAULT 0'),
            ('positions','engine',"TEXT DEFAULT 'jupiter'"), ('positions','buy_signature','TEXT')]:
            cur = await db.execute(f'PRAGMA table_info({table})')
            existing = {r[1] for r in await cur.fetchall()}
            if col not in existing:
                await db.execute(f'ALTER TABLE {table} ADD COLUMN {col} {definition}')
        defaults = {
            'buy_size_sol': '0.01', 'take_profit_pct': '30', 'stop_loss_pct': '15',
            'max_position_sol': str(config.max_position_sol), 'auto_enabled': '0',
            'buy_mode': 'manual', 'sell_mode': 'auto', 'engine': 'auto', 'stopped': '0',
            'max_slippage_bps': str(config.max_slippage_bps),
        }
        for key, value in defaults.items():
            await db.execute('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)', (key, value))
        await db.commit()

async def get_setting(key, default=None):
    async with await connect() as db:
        cur = await db.execute('SELECT value FROM settings WHERE key=?', (key,))
        row = await cur.fetchone()
        return row['value'] if row else default

async def set_setting(key, value):
    async with await connect() as db:
        await db.execute('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', (key, str(value)))
        await db.commit()

async def log_trade(side, mint, symbol, amount_sol, price_usd, status, note='', signature='', engine=''):
    async with await connect() as db:
        await db.execute('INSERT INTO trades(side,mint,symbol,amount_sol,price_usd,status,note,signature,engine) VALUES(?,?,?,?,?,?,?,?,?)',
                         (side, mint, symbol, amount_sol, price_usd, status, note, signature, engine))
        await db.commit()
