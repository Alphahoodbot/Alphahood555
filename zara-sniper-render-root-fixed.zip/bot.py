import asyncio
import logging
import os
import time
from datetime import datetime, timezone

import aiohttp
from solders.pubkey import Pubkey
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

from zara_sniper.config import config
from zara_sniper.db import init_db, connect, get_setting, set_setting, log_trade
from zara_sniper.market import fetch_latest_profiles, token_pairs, pair_metrics, best_pair, search_pairs
from zara_sniper.trading import LiveTrader, TradeError

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(name)s %(message)s')
log = logging.getLogger('zara-sniper')
PENDING_TTL_SECONDS = 60

async def owner_only(update: Update) -> bool:
    if not update.effective_user or update.effective_user.id != config.owner_id:
        if update.effective_message:
            await update.effective_message.reply_text('⛔ Private bot. This account is not authorized.')
        return False
    return True

async def get_session(context):
    session = context.application.bot_data.get('http')
    if session is None or session.closed:
        session = aiohttp.ClientSession()
        context.application.bot_data['http'] = session
    return session

async def get_trader(context):
    if config.trading_mode != 'live':
        raise TradeError('Live execution is disabled. Set TRADING_MODE=live and configure the required secrets in Render.')
    if context.application.bot_data.get('trader') is None:
        context.application.bot_data['trader'] = LiveTrader(await get_session(context))
    return context.application.bot_data['trader']

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await owner_only(update): return
    try:
        trader = await get_trader(context)
        bal = await trader.sol_balance()
        wallet = f'{trader.public_key}\nSOL balance: {bal:.5f} SOL'
    except Exception as e:
        wallet = f'Wallet setup: NOT READY ({str(e)[:140]})'
    await update.message.reply_text(
        '⚡ ZARA SNIPER by 0x Zara\n\n'
        f'Trading mode: {config.trading_mode.upper()}\n{wallet}\n\n'
        'Live trades use real funds. Start with a dedicated wallet and tiny amounts.\n'
        'Use /help for commands. Auto-buy is OFF until you explicitly enable it.'
    )

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await owner_only(update): return
    await update.message.reply_text(
        'ZARA SNIPER — live Solana trading controls\n\n'
        '/wallet — wallet address and SOL balance\n'
        '/discover — recent Solana token profiles\n'
        '/price <mint or symbol> — pair price and metrics\n'
        '/buy <mint> [SOL] [jupiter|pumpfun] — prepare live buy, then /confirm\n'
        '/sell <mint> [jupiter|pumpfun] — sell all of that mint\n'
        '/portfolio — on-chain token balances for saved positions\n'
        '/setbuy <SOL> — default buy amount\n'
        '/settp <percent> — auto take-profit threshold\n'
        '/setsl <percent> — auto stop-loss threshold\n'
        '/setslippage <bps> — max slippage in basis points (deployment cap applies)\n'
        '/setmax <SOL> — maximum amount per buy (bounded by deployment limit)\n'
        '/engine auto|jupiter|pumpfun — default trade route\n'
        '/mode manual|auto — manual approval or auto-buy mode\n'
        '/sellmode auto|manual — automatic TP/SL or manual selling\n'
        '/auto on|off — enable/disable the new-token auto-buyer\n'
        '/confirm /cancel — confirm or cancel pending buy\n'
        '/stop — emergency stop buys and automation\n'
        '/resume — clear emergency stop (auto-buy stays off)\n'
        '/history — recent on-chain trade records\n'
        '/settings — current controls\n\n'
        'Risk checks are not a guarantee. Newly launched tokens can be honeypots, liquidity can vanish, and trades can lose all funds.'
    )

async def wallet_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await owner_only(update): return
    try:
        trader = await get_trader(context)
        await update.message.reply_text(await trader.wallet_summary())
    except Exception as e:
        await update.message.reply_text(f'Wallet is not ready: {str(e)[:300]}')

async def discover(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await owner_only(update): return
    try:
        profiles = await fetch_latest_profiles(await get_session(context))
        if not profiles:
            await update.message.reply_text('No latest Solana token profiles returned right now.'); return
        lines = ['🛰️ Latest Solana token profiles (not safety-verified):']
        for x in profiles[:8]:
            lines.append(f"• {str(x.get('description') or 'Token profile')[:48]}\nMint: {x['tokenAddress']}")
        await update.message.reply_text('\n\n'.join(lines))
    except Exception as e:
        log.exception('discover failed')
        await update.message.reply_text(f'Market-data request failed: {type(e).__name__}.')

async def price(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await owner_only(update): return
    if not context.args:
        await update.message.reply_text('Usage: /price <token mint or symbol>'); return
    query = ' '.join(context.args)
    try:
        session = await get_session(context)
        if len(query) >= 32 and all(c in '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz' for c in query):
            pairs = await token_pairs(session, query)
            p = best_pair(pairs, query)
        else:
            p = best_pair(await search_pairs(session, query))
        if not p:
            await update.message.reply_text('No Solana pair found.'); return
        liq, vol, age = pair_metrics(p)
        age_text = f"{age:.2f}h" if age is not None else "unknown"
        await update.message.reply_text(
            f"{(p.get('baseToken') or {}).get('symbol','?')} / {(p.get('quoteToken') or {}).get('symbol','?')}\n"
            f"Price: ${p.get('priceUsd','n/a')}\nLiquidity: ${liq:,.0f}\n24h volume: ${vol:,.0f}\n"
            f"Pair age: {age_text}\nMint: {(p.get('baseToken') or {}).get('address','n/a')}\n\n"
            'Market metrics are not a token safety audit.'
        )
    except Exception as e:
        log.exception('price failed')
        await update.message.reply_text(f'Price lookup failed: {type(e).__name__}.')

async def daily_spend_today():
    day = datetime.now(timezone.utc).strftime('%Y-%m-%d')
    async with await connect() as db:
        cur = await db.execute('SELECT amount_sol FROM daily_spend WHERE day=?', (day,))
        row = await cur.fetchone()
    return float(row['amount_sol']) if row else 0.0

async def record_daily_spend(amount):
    day = datetime.now(timezone.utc).strftime('%Y-%m-%d')
    async with await connect() as db:
        await db.execute('INSERT INTO daily_spend(day,amount_sol) VALUES(?,?) ON CONFLICT(day) DO UPDATE SET amount_sol=amount_sol+excluded.amount_sol', (day, amount))
        await db.commit()

async def risk_check(mint, amount, engine, context):
    if await get_setting('stopped', '0') == '1':
        raise TradeError('Emergency stop is active. Use /resume first.')
    if amount <= 0:
        raise TradeError('Amount must be greater than zero.')
    maxpos = min(float(await get_setting('max_position_sol', str(config.max_position_sol))), config.max_position_sol)
    if amount > maxpos:
        raise TradeError(f'Amount {amount:g} SOL exceeds current max per trade ({maxpos:g} SOL). Use /setmax within deployment cap.')
    if await daily_spend_today() + amount > config.max_daily_spend_sol:
        raise TradeError(f'Daily spend cap reached. Deployment cap: {config.max_daily_spend_sol:g} SOL/day.')
    try:
        Pubkey.from_string(mint)
    except Exception as exc:
        raise TradeError('That does not look like a valid Solana mint address.') from exc
    if engine == 'jupiter':
        p = best_pair(await token_pairs(await get_session(context), mint), mint)
        if not p:
            raise TradeError('No DexScreener pair found for this mint. Jupiter buy blocked because there is no market data to screen. For Pump.fun bonding-curve tokens, choose pumpfun explicitly.')
        liq, vol, age = pair_metrics(p)
        if liq < config.min_liquidity_usd or vol < config.min_volume_24h_usd:
            raise TradeError(f'Liquidity/volume gate blocked buy: liquidity ${liq:,.0f}; 24h volume ${vol:,.0f}. This filter is not a safety guarantee.')
        if age is not None and age > config.max_token_age_hours:
            raise TradeError(f'Token pair age {age:.1f}h exceeds configured max {config.max_token_age_hours:g}h.')
    return maxpos

async def buy_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await owner_only(update): return
    if not context.args:
        await update.message.reply_text('Usage: /buy <mint> [SOL] [jupiter|pumpfun]'); return
    mint = context.args[0]
    try:
        amount = float(context.args[1]) if len(context.args) >= 2 else float(await get_setting('buy_size_sol', '0.01'))
        engine = context.args[2].lower() if len(context.args) >= 3 else await get_setting('engine', 'auto')
        if engine == 'auto': engine = 'jupiter'
        if engine not in ('jupiter', 'pumpfun'):
            raise TradeError('Engine must be jupiter or pumpfun.')
        await risk_check(mint, amount, engine, context)
        # Manual buys are always confirmed separately, to prevent accidental real trades.
        context.application.bot_data.setdefault('pending_buys', {})[update.effective_user.id] = {
            'mint': mint, 'amount': amount, 'engine': engine, 'created': time.time()
        }
        await update.message.reply_text(
            f'⚠️ LIVE BUY CONFIRMATION\nMint: {mint}\nAmount: {amount:g} SOL\nEngine: {engine}\n\n'
            'This will spend real SOL and may lose the full amount. Confirm within 60 seconds with /confirm, or /cancel.'
        )
    except (ValueError, TradeError) as e:
        await update.message.reply_text(f'Buy not prepared: {e}')
    except Exception as e:
        log.exception('buy preparation failed')
        await update.message.reply_text(f'Buy preparation failed: {type(e).__name__}. No trade intentionally submitted.')

async def _execute_buy_locked(update, context, mint, amount, engine):
    trader = await get_trader(context)
    # Re-check limits immediately before signing.
    await risk_check(mint, amount, engine, context)
    session = await get_session(context)
    pair = best_pair(await token_pairs(session, mint), mint)
    price_usd = float((pair or {}).get('priceUsd') or 0)
    symbol = ((pair or {}).get('baseToken') or {}).get('symbol', mint[:6])
    sig = await trader.buy(mint, amount, engine, int(await get_setting('max_slippage_bps', str(config.max_slippage_bps))))
    # The swap is already confirmed at this point. Log its signature before any optional balance lookup.
    await record_daily_spend(amount)
    await log_trade('BUY', mint, symbol, amount, price_usd, 'CONFIRMED', 'Swap confirmed; balance reconciliation follows', sig, engine)
    balance_note = ''
    raw, decimals, quantity = 0, 0, 0.0
    try:
        await asyncio.sleep(2)
        raw, decimals, quantity = await trader.token_balance(mint)
    except Exception as balance_exc:
        balance_note = f'\nBalance lookup delayed: {type(balance_exc).__name__}. Do not buy again until you check the signature/balance.'
        log.exception('on-chain buy confirmed but balance lookup failed')
    async with await connect() as db:
        await db.execute('INSERT INTO positions(mint,symbol,amount_sol,entry_price_usd,quantity,quantity_raw,decimals,engine,buy_signature) VALUES(?,?,?,?,?,?,?,?,?) '
                         'ON CONFLICT(mint) DO UPDATE SET symbol=excluded.symbol,amount_sol=positions.amount_sol+excluded.amount_sol,entry_price_usd=excluded.entry_price_usd,quantity=excluded.quantity,quantity_raw=excluded.quantity_raw,decimals=excluded.decimals,engine=excluded.engine,buy_signature=excluded.buy_signature',
                         (mint, symbol, amount, price_usd, quantity, str(raw), decimals, engine, sig))
        await db.commit()
    message = (f'✅ BUY CONFIRMED ON-CHAIN\n{symbol} | {amount:g} SOL\nReceived balance: {quantity:.8g} tokens\n'
               f'Engine: {engine}\nSignature: {sig}\nExplorer: https://solscan.io/tx/{sig}{balance_note}')
    if update is not None and getattr(update, 'effective_message', None):
        await update.effective_message.reply_text(message)
    else:
        await context.bot.send_message(chat_id=config.owner_id, text=message)

async def execute_buy(update, context, mint, amount, engine):
    # Serialize risk-check + execution to avoid concurrent commands overspending the daily cap.
    lock = context.application.bot_data.setdefault('trade_execution_lock', asyncio.Lock())
    active = context.application.bot_data.setdefault('active_buys', set())
    if mint in active:
        raise TradeError('A buy for this mint is already in progress. Check history and the chain before retrying.')
    async with lock:
        active.add(mint)
        try:
            async with await connect() as db:
                cur = await db.execute('SELECT 1 FROM positions WHERE mint=?', (mint,))
                existing = await cur.fetchone()
            if existing:
                raise TradeError('This mint already has a tracked position. Duplicate buys are blocked; sell or reconcile the existing position first.')
            await _execute_buy_locked(update, context, mint, amount, engine)
        finally:
            active.discard(mint)

async def confirm_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await owner_only(update): return
    pending = context.application.bot_data.setdefault('pending_buys', {}).pop(update.effective_user.id, None)
    if not pending:
        await update.message.reply_text('No pending buy. Use /buy <mint> [SOL] [jupiter|pumpfun] first.'); return
    if time.time() - pending['created'] > PENDING_TTL_SECONDS:
        await update.message.reply_text('Confirmation expired. Prepare the buy again.'); return
    await update.message.reply_text('Submitting the live transaction. Do not repeat if confirmation is delayed...')
    try:
        await execute_buy(update, context, pending['mint'], pending['amount'], pending['engine'])
    except Exception as e:
        log.exception('live buy failed')
        await update.effective_message.reply_text(f'Buy did not return a confirmed success: {str(e)[:500]}\nIf a signature was shown, check it before retrying.')

async def cancel_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await owner_only(update): return
    context.application.bot_data.setdefault('pending_buys', {}).pop(update.effective_user.id, None)
    await update.message.reply_text('Pending buy cancelled. No transaction submitted by this command.')

async def sell_mint(context, mint, forced_engine=None, user_message=None, symbol=None):
    trader = await get_trader(context)
    if await get_setting('stopped', '0') == '1':
        raise TradeError('Emergency stop is active. Use /resume before trading.')
    async with await connect() as db:
        cur = await db.execute('SELECT * FROM positions WHERE mint=?', (mint,))
        pos = await cur.fetchone()
    engine = forced_engine or (pos['engine'] if pos else 'jupiter')
    if engine not in ('jupiter', 'pumpfun'):
        engine = 'jupiter'
    raw, decimals, quantity = await trader.token_balance(mint)
    if raw <= 0:
        raise TradeError('No on-chain token balance found. Position was not removed.')
    sig = await trader.sell_all(mint, engine, int(await get_setting('max_slippage_bps', str(config.max_slippage_bps))))
    session = await get_session(context)
    p = best_pair(await token_pairs(session, mint), mint)
    price_usd = float((p or {}).get('priceUsd') or 0)
    sym = symbol or ((p or {}).get('baseToken') or {}).get('symbol') or (pos['symbol'] if pos else mint[:6])
    amount_sol = float(pos['amount_sol']) if pos else 0.0
    async with await connect() as db:
        await db.execute('DELETE FROM positions WHERE mint=?', (mint,))
        await db.commit()
    await log_trade('SELL', mint, sym, amount_sol, price_usd, 'CONFIRMED', f'sold all; previous raw balance {raw}', sig, engine)
    text = f'✅ SELL CONFIRMED ON-CHAIN\n{sym}\nEngine: {engine}\nSignature: {sig}\nExplorer: https://solscan.io/tx/{sig}'
    if user_message:
        await user_message.reply_text(text)
    return text

async def sell_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await owner_only(update): return
    if not context.args:
        await update.message.reply_text('Usage: /sell <mint> [jupiter|pumpfun]'); return
    mint = context.args[0]
    engine = context.args[1].lower() if len(context.args) > 1 else None
    if engine and engine not in ('jupiter', 'pumpfun'):
        await update.message.reply_text('Engine must be jupiter or pumpfun.'); return
    try:
        await update.message.reply_text('Submitting live sell. This sells the full on-chain balance of this mint; please do not repeat while pending.')
        await sell_mint(context, mint, engine, update.effective_message)
    except Exception as e:
        log.exception('sell failed')
        await update.message.reply_text(f'Sell not confirmed: {str(e)[:500]}')

async def portfolio(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await owner_only(update): return
    try:
        trader = await get_trader(context)
        sol = await trader.sol_balance()
        async with await connect() as db:
            cur = await db.execute('SELECT * FROM positions ORDER BY opened_at DESC')
            rows = await cur.fetchall()
        lines = [f'Wallet SOL: {sol:.6f}']
        if not rows: lines.append('No tracked positions. Any manually transferred tokens will not appear in the bot database.')
        for r in rows:
            raw, dec, qty = await trader.token_balance(r['mint'])
            lines.append(f"{r['symbol']} | actual balance {qty:.8g} | entry ${r['entry_price_usd']:.8g}\nMint: {r['mint']}\nEngine: {r['engine']}")
        await update.message.reply_text('\n\n'.join(lines))
    except Exception as e:
        await update.message.reply_text(f'Portfolio lookup failed: {str(e)[:300]}')

async def settings(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await owner_only(update): return
    keys = ['buy_size_sol','take_profit_pct','stop_loss_pct','max_position_sol','auto_enabled','buy_mode','sell_mode','engine','stopped','max_slippage_bps']
    vals = [f'{k}: {await get_setting(k, "?")}' for k in keys]
    await update.message.reply_text(f'Mode: {config.trading_mode}\nDeployment max/trade: {config.max_position_sol} SOL\nDaily spend cap: {config.max_daily_spend_sol} SOL\n' + '\n'.join(vals))

async def set_num(update, context, key, label, minimum, maximum):
    if not await owner_only(update): return
    if len(context.args) != 1:
        await update.message.reply_text(f'Usage: /{label} <number>'); return
    try: value = float(context.args[0])
    except ValueError:
        await update.message.reply_text('Please enter a valid number.'); return
    if not minimum <= value <= maximum:
        await update.message.reply_text(f'Value must be between {minimum} and {maximum}.'); return
    await set_setting(key, value)
    await update.message.reply_text(f'{label} set to {value}.')

async def setbuy(u,c): await set_num(u,c,'buy_size_sol','setbuy',0.0001,config.max_position_sol)
async def settp(u,c): await set_num(u,c,'take_profit_pct','settp',1,1000)
async def setsl(u,c): await set_num(u,c,'stop_loss_pct','setsl',1,99)
async def setmax(u,c): await set_num(u,c,'max_position_sol','setmax',0.0001,config.max_position_sol)
async def setslippage(u,c): await set_num(u,c,'max_slippage_bps','setslippage',1,config.max_slippage_bps)

async def set_choice(update, context, key, label, choices):
    if not await owner_only(update): return
    if len(context.args) != 1 or context.args[0].lower() not in choices:
        await update.message.reply_text(f'Usage: /{label} ' + '|'.join(choices)); return
    val = context.args[0].lower()
    await set_setting(key, val)
    await update.message.reply_text(f'{label} set to {val}.')

async def engine_cmd(u,c): await set_choice(u,c,'engine','engine',['auto','jupiter','pumpfun'])
async def mode_cmd(u,c): await set_choice(u,c,'buy_mode','mode',['manual','auto'])
async def sellmode_cmd(u,c): await set_choice(u,c,'sell_mode','sellmode',['auto','manual'])

async def auto_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await owner_only(update): return
    if not context.args or context.args[0].lower() not in ('on','off'):
        await update.message.reply_text('Usage: /auto on|off'); return
    enabled = context.args[0].lower() == 'on'
    if enabled:
        if await get_setting('stopped','0') == '1':
            await update.message.reply_text('Emergency stop is active. Use /resume first.'); return
        if await get_setting('buy_mode','manual') != 'auto':
            await update.message.reply_text('Auto-buy mode is not selected. Run /mode auto, review /settings, then /auto on.'); return
        try: await get_trader(context)
        except Exception as e:
            await update.message.reply_text(f'Cannot enable auto-buy: live wallet not ready ({str(e)[:180]}).'); return
    await set_setting('auto_enabled', '1' if enabled else '0')
    await update.message.reply_text('⚠️ Auto-buy enabled. It can spend real SOL within configured limits.' if enabled else 'Auto-buy disabled.')

async def stop_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await owner_only(update): return
    await set_setting('stopped','1'); await set_setting('auto_enabled','0')
    await update.message.reply_text('🛑 Emergency stop active: auto-buy disabled and automatic sells paused. It cannot cancel a transaction already submitted.')

async def resume_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await owner_only(update): return
    await set_setting('stopped','0')
    await update.message.reply_text('Emergency stop cleared. Auto-buy remains off until you explicitly run /auto on.')

async def history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await owner_only(update): return
    async with await connect() as db:
        cur = await db.execute('SELECT * FROM trades ORDER BY id DESC LIMIT 10')
        rows = await cur.fetchall()
    if not rows:
        await update.message.reply_text('No confirmed trade records yet.'); return
    lines = []
    for r in rows:
        sig = f"\n{r['signature']}" if r['signature'] else ''
        lines.append(f"{r['side']} {r['symbol'] or r['mint'][:6]} | {r['amount_sol']:.5f} SOL | {r['status']} | {r['engine'] or '?'}{sig}")
    await update.message.reply_text('Recent trade records:\n\n'+'\n\n'.join(lines))

async def monitor_positions(context: ContextTypes.DEFAULT_TYPE):
    if config.trading_mode != 'live' or await get_setting('stopped','0') == '1' or await get_setting('sell_mode','auto') != 'auto':
        return
    session = await get_session(context)
    async with await connect() as db:
        cur = await db.execute('SELECT * FROM positions')
        rows = await cur.fetchall()
    for row in rows:
        try:
            p = best_pair(await token_pairs(session, row['mint']), row['mint'])
            if not p or not p.get('priceUsd'): continue
            current = float(p['priceUsd']); entry = float(row['entry_price_usd'])
            if current <= 0: continue
            if entry <= 0:
                # Newly launched tokens may not have a price feed at purchase time. Track from the first
                # available quote and disclose that this is not the true execution entry price.
                async with await connect() as db:
                    await db.execute('UPDATE positions SET entry_price_usd=? WHERE mint=? AND entry_price_usd<=0', (current, row['mint']))
                    await db.commit()
                await context.bot.send_message(chat_id=config.owner_id, text=f'Price feed became available for {row["symbol"]}. TP/SL monitoring starts from this first available quote (${current:.8g}), not the actual buy price.')
                continue
            change = (current / entry - 1) * 100
            tp = float(await get_setting('take_profit_pct','30'))
            sl = float(await get_setting('stop_loss_pct','15'))
            if change >= tp or change <= -sl:
                active = context.application.bot_data.setdefault('active_sells', set())
                if row['mint'] in active:
                    continue
                active.add(row['mint'])
                reason = 'take-profit' if change >= tp else 'stop-loss'
                try:
                    log.warning('Auto sell trigger %s %s change %.2f%%', reason, row['mint'], change)
                    await context.bot.send_message(chat_id=config.owner_id, text=f'Auto-sell trigger: {row["symbol"]} {change:+.2f}% ({reason}). Submitting full-balance sell...')
                    await sell_mint(context, row['mint'], row['engine'], None, row['symbol'])
                    await context.bot.send_message(chat_id=config.owner_id, text=f'Auto-sell completed for {row["symbol"]}.')
                finally:
                    active.discard(row['mint'])
        except Exception as e:
            log.exception('position monitor error for %s', row['mint'])
            await context.bot.send_message(chat_id=config.owner_id, text=f'Auto-sell check failed for {row["mint"][:8]}…: {str(e)[:180]}')

async def on_new_pump_token(context, token):
    mint = token.get('mint')
    if not mint: return
    async with await connect() as db:
        cur = await db.execute('SELECT 1 FROM seen_tokens WHERE mint=?', (mint,))
        if await cur.fetchone(): return
        await db.execute('INSERT OR IGNORE INTO seen_tokens(mint) VALUES(?)', (mint,))
        await db.commit()
    if await get_setting('auto_enabled','0') != '1' or await get_setting('buy_mode','manual') != 'auto' or await get_setting('stopped','0') == '1':
        return
    # PumpPortal's bonding-curve virtual SOL reserve is only a rough launch signal, not true withdrawable liquidity.
    try: curve_sol = float(token.get('vSolInBondingCurve') or 0) / 1_000_000_000
    except (ValueError, TypeError): curve_sol = 0
    min_curve_sol = float(__import__('os').getenv('AUTO_MIN_VIRTUAL_SOL', '20'))
    if curve_sol < min_curve_sol:
        return
    amount = float(await get_setting('buy_size_sol','0.01'))
    try:
        from types import SimpleNamespace
        app_context = SimpleNamespace(application=context, bot=context.bot, bot_data=context.bot_data)
        await risk_check(mint, amount, 'pumpfun', app_context)
        await context.bot.send_message(chat_id=config.owner_id, text=f'🚨 New Pump.fun token passed the basic reserve filter. Auto-buy attempt\n{token.get("symbol", "?")} — {mint}\nVirtual SOL reserve: {curve_sol:.2f} (not actual liquidity)\nAmount: {amount:g} SOL')
        await execute_buy(None, app_context, mint, amount, 'pumpfun')
    except Exception as e:
        log.warning('Auto-buy skipped for %s: %s', mint, e)
        await context.bot.send_message(chat_id=config.owner_id, text=f'Auto-buy skipped/failed for {mint}: {str(e)[:250]}')

async def pumpportal_listener(app):
    # PumpPortal real-time launch feed. Reconnects after disconnects; no auto-buy until explicitly enabled.
    url = 'wss://pumpportal.fun/api/data'
    while True:
        try:
            session = app.bot_data.get('http')
            if session is None or session.closed:
                await asyncio.sleep(2); continue
            async with session.ws_connect(url, heartbeat=25, timeout=20) as ws:
                await ws.send_json({'method': 'subscribeNewToken'})
                log.info('Subscribed to PumpPortal new-token feed')
                async for msg in ws:
                    if msg.type == aiohttp.WSMsgType.TEXT:
                        try: token = msg.json()
                        except Exception: continue
                        if isinstance(token, dict) and token.get('mint'):
                            await on_new_pump_token(app, token)
                    elif msg.type in (aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.ERROR):
                        break
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception('PumpPortal websocket disconnected; retrying')
        await asyncio.sleep(5)

async def post_init(app):
    await init_db()
    # Create the HTTP session before the websocket listener starts. Without this,
    # a quiet bot would never connect to the new-token feed until a command arrived.
    app.bot_data['http'] = aiohttp.ClientSession()
    app.bot_data['active_sells'] = set()
    # Live wallet initialization is best-effort so market-data commands can still respond if secrets are incomplete.
    if config.trading_mode == 'live' and config.solana_private_key and config.solana_rpc_url:
        try:
            trader = get_trader
            log.info('Live execution configured; wallet is loaded lazily on first command')
        except Exception:
            log.exception('Could not initialize live trader')
    app.bot_data['pump_task'] = asyncio.create_task(pumpportal_listener(app))
    if app.job_queue:
        app.job_queue.run_repeating(monitor_positions, interval=15, first=20, name='tp-sl-monitor')

async def post_shutdown(app):
    task = app.bot_data.get('pump_task')
    if task:
        task.cancel()
        try: await task
        except asyncio.CancelledError: pass
    session = app.bot_data.get('http')
    if session and not session.closed: await session.close()

async def error_handler(update, context):
    log.error('Unhandled exception', exc_info=context.error)

def main():
    if not config.telegram_token or config.telegram_token == 'replace_me':
        raise SystemExit('Set TELEGRAM_BOT_TOKEN in your deployment environment first.')
    if config.owner_id <= 0:
        raise SystemExit('Set OWNER_ID to your numeric Telegram user ID in the deployment environment.')
    if config.trading_mode not in ('live', 'paper'):
        raise SystemExit('TRADING_MODE must be live or paper.')
    if config.trading_mode == 'live' and (not config.solana_rpc_url or not config.solana_private_key):
        log.warning('LIVE MODE selected but wallet/RPC secrets are missing. Trading commands will fail closed until configured.')
    if config.trading_mode == 'live' and config.auto_buy_enabled_at_start:
        log.warning('AUTO_BUY_ENABLED_AT_START is ignored for safety. Auto-buy must be explicitly enabled by the owner after startup.')
    app = Application.builder().token(config.telegram_token).post_init(post_init).post_shutdown(post_shutdown).build()
    commands = {
        'start':start,'help':help_cmd,'wallet':wallet_cmd,'balance':wallet_cmd,'discover':discover,'price':price,'buy':buy_cmd,'sell':sell_cmd,
        'confirm':confirm_cmd,'cancel':cancel_cmd,'portfolio':portfolio,'settings':settings,'setbuy':setbuy,'settp':settp,
        'setsl':setsl,'setmax':setmax,'setslippage':setslippage,'engine':engine_cmd,'mode':mode_cmd,'sellmode':sellmode_cmd,'auto':auto_cmd,
        'stop':stop_cmd,'resume':resume_cmd,'history':history,
    }
    for name, fn in commands.items(): app.add_handler(CommandHandler(name, fn))
    app.add_error_handler(error_handler)
    log.info('ZARA SNIPER starting; mode=%s; auto-buy is off by default', config.trading_mode)
    telegram_mode = os.getenv('TELEGRAM_MODE', 'polling').strip().lower()
    if telegram_mode == 'webhook':
        # Render web services require an HTTP listener. Webhook mode is intended for
        # command handling on a web service; free instances are not reliable for
        # continuous token monitoring or automated trading.
        external_url = os.getenv('RENDER_EXTERNAL_URL') or os.getenv('WEBHOOK_URL', '')
        if not external_url.startswith('https://'):
            raise SystemExit('TELEGRAM_MODE=webhook requires RENDER_EXTERNAL_URL or WEBHOOK_URL with an https:// URL.')
        port = int(os.getenv('PORT', '10000'))
        secret = os.getenv('WEBHOOK_SECRET_TOKEN', '').strip() or None
        app.run_webhook(
            listen='0.0.0.0', port=port, url_path='telegram',
            webhook_url=external_url.rstrip('/'), secret_token=secret,
            drop_pending_updates=True,
        )
    elif telegram_mode == 'polling':
        app.run_polling(drop_pending_updates=True)
    else:
        raise SystemExit('TELEGRAM_MODE must be polling or webhook.')

if __name__ == '__main__': main()
